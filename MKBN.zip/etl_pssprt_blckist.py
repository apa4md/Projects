import pandas
import jaydebeapi
import os
import re
import datetime
import shutil
conn = jaydebeapi.connect( 
'oracle.jdbc.driver.OracleDriver',
'jdbc:oracle:thin:de1m/samwisegamgee@de-oracle.chronosavant.ru:1521/deoracle',
['de1m','samwisegamgee'],
'/home/de1m/ojdbc8.jar'
)
curs = conn.cursor()
conn.jconn.setAutoCommit(False)
for file in os.listdir('/home/de1m/mkbn'):
    if re.search('blacklist.',file):
        passport_blacklist=os.path.join('/home/de1m/mkbn',file)
df=pandas.read_excel(passport_blacklist,sheet_name='blacklist',header=0,index_col=None)
df=df.reindex(columns=['passport','date'])
name,ext=os.path.splitext(passport_blacklist)
dt=datetime.datetime.strptime(str(name.split('_')[-1]), '%d%m%Y')
dt_to_sql=dt.strftime('%Y-%m-%d %H:%M:%S')
df=df.loc[df['date']==dt_to_sql[:10]]
df=df.astype(str)
curs.executemany("insert into de1m.mkbn_dwh_fact_pssprt_blcklst(passport_num,entry_dt) values(?,to_date(?,'YYYY-MM-DD HH24:MI:SS'))",df.values.tolist())
conn.commit()
os.rename(passport_blacklist,passport_blacklist+".backup")
source_path=passport_blacklist+".backup"
if os.path.exists(source_path):
    destination_path=r"/home/de1m/mkbn/archive"
    new_location = shutil.move(source_path, destination_path)
curs.close()
conn.close()