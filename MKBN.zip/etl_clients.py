import jaydebeapi

conn = jaydebeapi.connect( 
'oracle.jdbc.driver.OracleDriver',
'jdbc:oracle:thin:de1m/samwisegamgee@de-oracle.chronosavant.ru:1521/deoracle',
['de1m','samwisegamgee'],
'/home/de1m/ojdbc8.jar'
)
curs = conn.cursor()
conn.jconn.setAutoCommit(False)

#1. Загрузка в STG (захват, extract)

curs.execute("truncate table de1m.mkbn_stg_clients")
curs.execute("truncate table de1m.mkbn_stg_clients_del")

curs.execute("""
insert into de1m.mkbn_stg_clients (CLIENT_ID,LAST_NAME,FIRST_NAME,PATRONYMIC,DATE_OF_BIRTH,PASSPORT_NUM,PASSPORT_VALID_TO,PHONE,CREATE_DT,UPDATE_DT)
select 
    CLIENT_ID,
    LAST_NAME,
    FIRST_NAME,
    PATRONYMIC,
    DATE_OF_BIRTH,
    PASSPORT_NUM,
    coalesce(PASSPORT_VALID_TO,to_date( '31.12.9999', 'DD.MM.YYYY' )),
    PHONE,
    create_dt,
    update_dt
from de1m.mkbn_clients
where coalesce(update_dt,create_dt) > coalesce( ( 
    select max_update_dt
    from de1m.mkbn_meta_project
    where schema_name = 'DE1M' and table_name = 'mkbn_SOURCE_clients'
), to_date( '1800.01.01', 'YYYY.MM.DD' ))""")

curs.execute("""
update de1m.mkbn_curr_time
set curr_date=current_date""")

curs.execute("""
insert into de1m.mkbn_stg_clients_del ( client_id )
select client_id from de1m.mkbn_clients""")

# 2. Выделение вставок и изменений (transform); вставка в их приемник (load)
curs.execute("""
merge into de1m.mkbn_dwh_dim_clients_hist tgt
using de1m.mkbn_stg_clients stg
on( stg.client_id = tgt.client_id and deleted_flg = 'N' )
when matched then 
    update set tgt.effective_to = stg.update_dt - interval '1' second
    where 1=1
	and tgt.effective_to = to_date( '31.12.9999', 'DD.MM.YYYY' )
	and (1=0
    or stg.last_name <> tgt.last_name or ( stg.last_name is null and tgt.last_name is not null ) or ( stg.last_name is not null and tgt.last_name is null )
	)
    and (1=0
    or stg.first_name <> tgt.first_name or ( stg.first_name is null and tgt.first_name is not null ) or ( stg.first_name is not null and tgt.first_name is null )
	)
    and (1=0
    or stg.patronymic <> tgt.patronymic or ( stg.patronymic is null and tgt.patronymic is not null ) or ( stg.patronymic is not null and tgt.patronymic is null )
	)
    and (1=0
    or stg.date_of_birth <> tgt.date_of_birth or ( stg.date_of_birth is null and tgt.date_of_birth is not null ) or ( stg.date_of_birth is not null and tgt.date_of_birth is null )
	)
    and (1=0
    or stg.passport_num <> tgt.passport_num or ( stg.passport_num is null and tgt.passport_num is not null ) or ( stg.passport_num is not null and tgt.passport_num is null )
	)
    and (1=0
    or stg.passport_valid_to <> tgt.passport_valid_to or ( stg.passport_valid_to is null and tgt.passport_valid_to is not null ) or ( stg.passport_valid_to is not null and tgt.passport_valid_to is null )
	)
    and (1=0
    or stg.phone <> tgt.phone or ( stg.phone is null and tgt.phone is not null ) or ( stg.phone is not null and tgt.phone is null )
	)
when not matched then 
    insert ( client_id,last_name,first_name,patronymic,date_of_birth,passport_num,passport_valid_to,phone,effective_from,effective_to,deleted_flg  ) 
    values ( stg.client_id,stg.last_name,stg.first_name,stg.patronymic,stg.date_of_birth,stg.passport_num,stg.passport_valid_to,stg.phone,coalesce(update_dt,create_dt),to_date( '31.12.9999', 'DD.MM.YYYY' ), 'N' )""")

curs.execute("""
insert into de1m.mkbn_dwh_dim_clients_hist ( client_id,last_name,first_name,patronymic,date_of_birth,passport_num,passport_valid_to,phone,effective_from,effective_to,deleted_flg  ) 
select
    stg.client_id,
    stg.last_name,
    stg.first_name,
    stg.patronymic,
    stg.date_of_birth,
    stg.passport_num,
    stg.passport_valid_to,
    stg.phone,
    stg.update_dt,
    to_date( '31.12.9999', 'DD.MM.YYYY' ), 
    'N'
from de1m.mkbn_dwh_dim_clients_hist tgt
inner join de1m.mkbn_stg_clients stg
on ( stg.client_id = tgt.client_id and (tgt.effective_to =stg.update_dt + interval '1' second) and deleted_flg = 'N' )
where 1=0
    or stg.last_name <> tgt.last_name or ( stg.last_name is null and tgt.last_name is not null ) or ( stg.last_name is not null and tgt.last_name is null )
    or stg.first_name <> tgt.first_name or ( stg.first_name is null and tgt.first_name is not null ) or ( stg.first_name is not null and tgt.first_name is null )
    or stg.patronymic <> tgt.patronymic or ( stg.patronymic is null and tgt.patronymic is not null ) or ( stg.patronymic is not null and tgt.patronymic is null )
    or stg.date_of_birth <> tgt.date_of_birth or ( stg.date_of_birth is null and tgt.date_of_birth is not null ) or ( stg.date_of_birth is not null and tgt.date_of_birth is null )
    or stg.passport_num <> tgt.passport_num or ( stg.passport_num is null and tgt.passport_num is not null ) or ( stg.passport_num is not null and tgt.passport_num is null )
    or stg.passport_valid_to <> tgt.passport_valid_to or ( stg.passport_valid_to is null and tgt.passport_valid_to is not null ) or ( stg.passport_valid_to is not null and tgt.passport_valid_to is null )
    or stg.phone <> tgt.phone or ( stg.phone is null and tgt.phone is not null ) or ( stg.phone is not null and tgt.phone is null )""")

# 3. Обработка удалений.

curs.execute("""
insert into de1m.mkbn_dwh_dim_clients_hist ( client_id,last_name,first_name,patronymic,date_of_birth,passport_num,passport_valid_to,phone,effective_from,effective_to,deleted_flg  ) 
select
    tgt.client_id,
    tgt.last_name,
    tgt.first_name,
    tgt.patronymic,
    tgt.date_of_birth,
    tgt.passport_num,
    tgt.passport_valid_to,
    tgt.phone, 
    curr_date,
    to_date( '31.12.9999', 'DD.MM.YYYY' ), 
    'Y'
from de1m.mkbn_curr_time,de1m.mkbn_dwh_dim_clients_hist tgt
left join de1m.mkbn_stg_clients_del stg
on ( stg.client_id = tgt.client_id and tgt.effective_to = to_date( '31.12.9999', 'DD.MM.YYYY' ) and deleted_flg = 'N' )
where stg.client_id is null""")

curs.execute("""
update de1m.mkbn_dwh_dim_clients_hist tgt
set effective_to = (select curr_date from de1m.mkbn_curr_time) - interval '1' second
where tgt.client_id not in (select client_id from de1m.mkbn_stg_clients_del)
and tgt.effective_to = to_date( '31.12.9999', 'DD.MM.YYYY' )
and tgt.deleted_flg = 'N'""")


# 4. Обновление метаданных.

curs.execute("""
merge into de1m.mkbn_meta_project trg
using ( select 'DE1M' schema_name, 'mkbn_SOURCE_clients' table_name, ( select max( update_dt ) from de1m.mkbn_stg_clients ) max_update_dt from dual ) src
on ( trg.schema_name = src.schema_name and trg.table_name = src.table_name )
when matched then 
    update set trg.max_update_dt = src.max_update_dt
    where src.max_update_dt is not null
when not matched then 
    insert ( schema_name, table_name, max_update_dt )
    values ( 'DE1M', 'mkbn_SOURCE_clients',coalesce( src.max_update_dt, to_date( '01.01.1900', 'DD.MM.YYYY' )))""")

conn.commit()
curs.close()
conn.close()
