import jaydebeapi

conn = jaydebeapi.connect( 
'oracle.jdbc.driver.OracleDriver',
'jdbc:oracle:thin:de1m/samwisegamgee@de-oracle.chronosavant.ru:1521/deoracle',
['de1m','samwisegamgee'],
'/home/de1m/ojdbc8.jar'
)
curs = conn.cursor()
conn.jconn.setAutoCommit(False)
import os
import re
import datetime

a='00000000'
for file in os.listdir(r'/home/de1m/mkbn/archive'):
    if re.search('transactions.',file):
        if file[13:21]>a:
            a=file[13:21]
            transactions=file
name, ext = os.path.splitext(transactions)
name,ext=os.path.splitext(name)
dt=datetime.datetime.strptime(str(name.split('_')[-1]), '%d%m%Y')
dt_to_sql=dt.strftime('%Y-%m-%d %H:%M:%S')

curs.execute("""
insert into de1m.mkbn_rep_fraud(event_dt,passport,fio,phone,event_type,report_dt)
select
    stg.trans_date,
    stg.passport_num,
    stg.fio,
    stg.phone,
    stg.event_type,
    stg.report_dt
from de1m.mkbn_rep_fraud tgt
right join(
select 
    trans_date,
    cl.passport_num,
    last_name || ' ' ||  first_name || ' ' || patronymic fio,
    phone,
    '1' event_type,
    to_date('{0}','YYYY.MM.DD HH24-MI-SS')+interval '1' day report_dt
from de1m.mkbn_dwh_fact_transactions tr 
left join de1m.mkbn_dwh_dim_cards_hist c 
    on tr.card_num=c.card_num and tr.trans_date between c.effective_from and c.effective_to 
left join de1m.mkbn_dwh_dim_accounts_hist a 
    on c.account_num=a.account_num and tr.trans_date between a.effective_from and a.effective_to
left join de1m.mkbn_dwh_dim_clients_hist cl 
    on a.client=cl.client_id and tr.trans_date between cl.effective_from and cl.effective_to
left join de1m.mkbn_dwh_fact_pssprt_blcklst p 
    on cl.passport_num=p.passport_num
where trans_date-interval '1' day>passport_valid_to or trans_date>entry_dt) stg
on tgt.event_dt=stg.trans_date
where tgt.event_dt is null""".format(dt_to_sql))

curs.execute("""
insert into de1m.mkbn_rep_fraud(event_dt,passport,fio,phone,event_type,report_dt)
select
    stg.trans_date,
    stg.passport_num,
    stg.fio,
    stg.phone,
    stg.event_type,
    stg.report_dt
from de1m.mkbn_rep_fraud tgt
right join(
select 
    trans_date,
    passport_num,
    last_name || ' ' ||  first_name || ' ' || patronymic fio,
    phone,
    '2' event_type,
    to_date('{0}','YYYY.MM.DD HH24-MI-SS')+interval '1' day report_dt
from de1m.mkbn_dwh_fact_transactions tr 
left join de1m.mkbn_dwh_dim_cards_hist c 
    on tr.card_num=c.card_num and tr.trans_date between c.effective_from and c.effective_to
left join de1m.mkbn_dwh_dim_accounts_hist a 
    on c.account_num=a.account_num and tr.trans_date between a.effective_from and a.effective_to
left join de1m.mkbn_dwh_dim_clients_hist cl 
    on a.client=cl.client_id and tr.trans_date between cl.effective_from and cl.effective_to
where a.valid_to<trans_date-interval '1' day) stg
on tgt.event_dt=stg.trans_date
where tgt.event_dt is null""".format(dt_to_sql))

curs.execute("""
insert into de1m.mkbn_rep_fraud(event_dt,passport,fio,phone,event_type,report_dt)
select
    stg.trans_date,
    stg.passport_num,
    stg.fio,
    stg.phone,
    stg.event_type,
    stg.report_dt
from de1m.mkbn_rep_fraud tgt
right join (
select 
    trans_date,
    passport_num,
    last_name || ' ' ||  first_name || ' ' || patronymic fio,
    phone,'3' event_type,
    to_date('{0}','YYYY.MM.DD HH24-MI-SS')+interval '1' day report_dt
from 
(
select card_num,trans_id,trans_date
from(
select 
    card_num,
    trans_id,
    trans_date,
    terminal_city,
    lag(trans_date) over(partition by card_num order by trans_date) lag_date,
    oper_type,lag(oper_type) over(partition  by card_num order by trans_date) lag_oper_type,
    lag(terminal_city) over(partition  by card_num order by trans_date) lag_city
from de1m.mkbn_dwh_fact_transactions tr left join de1m.mkbn_dwh_dim_terminals_hist t 
    on tr.terminal=t.terminal_id and tr.trans_date between t.effective_from and t.effective_to and deleted_flg='N'
where card_num in(
select card_num
from de1m.mkbn_dwh_fact_transactions tr left join de1m.mkbn_dwh_dim_terminals_hist t 
    on tr.terminal=t.terminal_id and tr.trans_date between t.effective_from and t.effective_to and deleted_flg='N'
group by card_num
having count(distinct(terminal_city))>1)
    )t1
where terminal_city<>lag_city and oper_type='WITHDRAW' and trans_date<lag_date+ interval '1' hour
)t2 
left join de1m.mkbn_dwh_dim_cards_hist c 
    on t2.card_num=c.card_num and t2.trans_date between c.effective_from and c.effective_to
left join de1m.mkbn_dwh_dim_accounts_hist a 
    on c.account_num=a.account_num and t2.trans_date between a.effective_from and a.effective_to
left join de1m.mkbn_dwh_dim_clients_hist cl 
    on a.client=cl.client_id and t2.trans_date between cl.effective_from and cl.effective_to
            ) stg 
on tgt.event_dt=stg.trans_date
where tgt.event_dt is null""".format(dt_to_sql))

curs.execute("""
insert into de1m.mkbn_rep_fraud(event_dt,passport,fio,phone,event_type,report_dt)
select
    stg.trans_date,
    stg.passport_num,
    stg.fio,
    stg.phone,
    stg.event_type,
    stg.report_dt
from de1m.mkbn_rep_fraud tgt
right join(
select 
    trans_date,
    passport_num,
    last_name || ' ' ||  first_name || ' ' || patronymic fio,
    phone,'4' event_type,
    to_date('{0}','YYYY.MM.DD HH24-MI-SS')+interval '1' day report_dt
from (
select 
    trans_date,
    trans_id,
    t3.card_num
from (
select 
    trans_id,
    trans_date,
    amt,
    card_num,
    oper_type,
    oper_result,
    terminal,
    row_number() over(partition by card_num order by trans_date) row_num_dt
from de1m.mkbn_dwh_fact_transactions) t3 inner join
(
select 
    row_num_dt,
    lead_amt,
    card_num,
    lag_dt
from(
select 
    trans_id,
    trans_date,
    amt,
    card_num,
    oper_type,
    oper_result,
    terminal,
    row_number() over(partition by card_num order by trans_date) row_num_dt,
    lead(oper_result) over (partition by card_num order by trans_date) lead_res,
    lag(oper_result) over (partition by card_num order by trans_date) lag_res,
    lead(oper_type) over (partition by card_num order by trans_date) lead_oper_type,
    lag(oper_type) over (partition by card_num order by trans_date) lag_oper_type,
    lead(amt) over (partition by card_num order by trans_date) lead_amt,
    lag(amt) over (partition by card_num order by trans_date) lag_amt,
    lead(trans_date) over (partition by card_num order by trans_date) lead_dt,
    lag(trans_date) over (partition by card_num order by trans_date) lag_dt
from de1m.mkbn_dwh_fact_transactions
    )t1
where oper_result=lead_res and oper_result=lag_res
and oper_result='REJECT' and amt<lag_amt and amt>lead_amt and oper_type='WITHDRAW' and lag_oper_type='WITHDRAW'
)t4
on t3.row_num_dt=t4.row_num_dt+2 and t3.oper_result='SUCCESS' and t3.oper_type='WITHDRAW' and t3.amt<t4.lead_amt and t3.card_num=t4.card_num) t5
left join de1m.mkbn_dwh_dim_cards_hist c 
    on t5.card_num=c.card_num and t5.trans_date between c.effective_from and c.effective_to
left join de1m.mkbn_dwh_dim_accounts_hist a 
    on c.account_num=a.account_num and t5.trans_date between a.effective_from and a.effective_to
left join de1m.mkbn_dwh_dim_clients_hist cl 
    on a.client=cl.client_id and t5.trans_date between cl.effective_from and cl.effective_to
            ) stg 
on tgt.event_dt=stg.trans_date
where tgt.event_dt is null""".format(dt_to_sql))

conn.commit()
curs.close()
conn.close()