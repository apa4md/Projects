import jaydebeapi

conn = jaydebeapi.connect( 
'oracle.jdbc.driver.OracleDriver',
'jdbc:oracle:thin:de1m/samwisegamgee@de-oracle.chronosavant.ru:1521/deoracle',
['de1m','samwisegamgee'],
'/home/de1m/ojdbc8.jar'
)
curs = conn.cursor()
conn.jconn.setAutoCommit(False)
	
	#1.Инкрементальная загрузка

curs.execute("truncate table de1m.mkbn_stg_accounts")
curs.execute("truncate table de1m.mkbn_stg_accounts_del")

curs.execute("""
insert into de1m.mkbn_stg_accounts (account,valid_to,client,CREATE_DT,UPDATE_DT)
select 
    account,
    valid_to,
    client,
    create_dt,
    update_dt
from de1m.mkbn_accounts
where coalesce(update_dt,create_dt) >= coalesce( ( 
    select max_update_dt
    from de1m.mkbn_meta_project
    where schema_name = 'DE1M' and table_name = 'mkbn_SOURCE_accounts'
), to_date( '1800.01.01', 'YYYY.MM.DD' ))""")

curs.execute("""
insert into de1m.mkbn_stg_accounts_del ( account )
select account from de1m.mkbn_accounts""")

	#2. Выделение вставок и изменений (transform); вставка в их приемник (load)
	
curs.execute("""
merge into de1m.mkbn_dwh_dim_accounts_hist tgt
using de1m.mkbn_stg_accounts stg
on( stg.account = tgt.account_num and deleted_flg = 'N' )
when matched then 
    update set tgt.effective_to = stg.update_dt - interval '1' second
    where 1=1
	and tgt.effective_to = to_date( '31.12.9999', 'DD.MM.YYYY' )
    and (1=0
    or stg.valid_to <> tgt.valid_to or ( stg.valid_to is null and tgt.valid_to is not null ) or ( stg.valid_to is not null and tgt.valid_to is null )
	)
    and (1=0
    or stg.client <> tgt.client or ( stg.client is null and tgt.client is not null ) or ( stg.client is not null and tgt.client is null )
	)
when not matched then 
    insert ( account_num,valid_to,client,effective_from,effective_to,deleted_flg  ) 
    values ( stg.account,stg.valid_to,stg.client,coalesce(update_dt,create_dt),to_date( '31.12.9999', 'DD.MM.YYYY' ), 'N' )""")

curs.execute("""
insert into de1m.mkbn_dwh_dim_accounts_hist ( account_num,valid_to,client,effective_from,effective_to,deleted_flg  ) 
select
    stg.account,
    stg.valid_to,
    stg.client,
    stg.update_dt,
    to_date( '31.12.9999', 'DD.MM.YYYY' ), 
    'N'
from de1m.mkbn_dwh_dim_accounts_hist tgt
inner join de1m.mkbn_stg_accounts stg
on ( stg.account = tgt.account_num and (tgt.effective_to =stg.update_dt + interval '1' second) and deleted_flg = 'N' )
where 1=0
    or stg.valid_to <> tgt.valid_to or ( stg.valid_to is null and tgt.valid_to is not null ) or ( stg.valid_to is not null and tgt.valid_to is null )
    or stg.client <> tgt.client or ( stg.client is null and tgt.client is not null ) or ( stg.client is not null and tgt.client is null )""")

	#3. Обработка удалений.

curs.execute("""
update de1m.mkbn_curr_time
set curr_date=current_date""")

curs.execute("""
insert into de1m.mkbn_dwh_dim_accounts_hist ( account_num,valid_to,client,effective_from,effective_to,deleted_flg  ) 
select
    tgt.account_num,
    tgt.valid_to,
    tgt.client,
    curr_date,
    to_date( '31.12.9999', 'DD.MM.YYYY' ), 
    'Y'
from de1m.mkbn_curr_time,de1m.mkbn_dwh_dim_accounts_hist tgt
left join de1m.mkbn_stg_accounts_del stg
on ( stg.account = tgt.account_num and tgt.effective_to = to_date( '31.12.9999', 'DD.MM.YYYY' ) and deleted_flg = 'N' )
where stg.account is null""")

curs.execute("""
update de1m.mkbn_dwh_dim_accounts_hist tgt
set effective_to = (select curr_date from de1m.mkbn_curr_time) - interval '1' second
where tgt.account_num not in (select account from de1m.mkbn_stg_accounts_del)
and tgt.effective_to = to_date( '31.12.9999', 'DD.MM.YYYY' )
and tgt.deleted_flg = 'N'""")

	#4. Обновление метаданных.

curs.execute("""
merge into de1m.mkbn_meta_project trg
using ( select 'DE1M' schema_name, 'mkbn_SOURCE_accounts' table_name, ( select max( update_dt ) from de1m.mkbn_stg_accounts ) max_update_dt from dual ) src
on ( trg.schema_name = src.schema_name and trg.table_name = src.table_name )
when matched then 
    update set trg.max_update_dt = src.max_update_dt
    where src.max_update_dt is not null
when not matched then 
    insert ( schema_name, table_name, max_update_dt )
    values ( 'DE1M', 'mkbn_SOURCE_accounts',coalesce( src.max_update_dt, to_date( '01.01.1900', 'DD.MM.YYYY' )))""")

conn.commit()
curs.close()
conn.close()