import pandas
import jaydebeapi
import os
import re
import datetime
import shutil
conn = jaydebeapi.connect( 
'oracle.jdbc.driver.OracleDriver',
'jdbc:oracle:thin:de1m/samwisegamgee@de-oracle.chronosavant.ru:1521/deoracle',
['de1m','samwisegamgee'],
'/home/de1m/ojdbc8.jar'
)
curs = conn.cursor()
conn.jconn.setAutoCommit(False)
for file in os.listdir('/home/de1m/mkbn'):
    if re.search('terminals.',file):
        terminals=os.path.join('/home/de1m/mkbn',file)
df=pandas.read_excel(terminals,sheet_name='terminals',header=0,index_col=None)
df=df.astype(str)
curs.execute("truncate table de1m.mkbn_stg_terminals")
curs.execute("truncate table de1m.mkbn_stg_terminals_del")
curs.executemany("insert into de1m.mkbn_stg_terminals(terminal_id,terminal_type,terminal_city,terminal_address) values(?,?,?,?)",df.values.tolist())
curs.execute("insert into de1m.mkbn_stg_terminals_del(terminal_id) select terminal_id from de1m.mkbn_stg_terminals")
name,ext=os.path.splitext(terminals)
dt=datetime.datetime.strptime(str(name.split('_')[-1]), '%d%m%Y')
dt_to_sql=dt.strftime('%Y-%m-%d %H:%M:%S')
curs.execute("""merge into de1m.mkbn_dwh_dim_terminals_hist tgt
using de1m.mkbn_stg_terminals stg
on( stg.terminal_id = tgt.terminal_id and deleted_flg = 'N' )
when matched then 
    update set tgt.effective_to =  to_date('{0}','YYYY.MM.DD HH24-MI-SS')-interval '1' second
    where 1=1
    and tgt.effective_to = to_date( '31.12.9999 00-00-00', 'DD.MM.YYYY HH24-MI-SS' )
    and (1=0
    or stg.terminal_type <> tgt.terminal_type or ( stg.terminal_type is null and tgt.terminal_type is not null ) or ( stg.terminal_type is not null and tgt.terminal_type is null )
)
    and (1=0
    or stg.terminal_city <> tgt.terminal_city or ( stg.terminal_city is null and tgt.terminal_city is not null ) or ( stg.terminal_city is not null and tgt.terminal_city is null )
)
    and (1=0
    or stg.terminal_address <> tgt.terminal_address or ( stg.terminal_address is null and tgt.terminal_address is not null ) or ( stg.terminal_address is not null and tgt.terminal_address is null )
)
when not matched then 
    insert ( terminal_id,terminal_type,terminal_city,terminal_address,effective_from,effective_to,deleted_flg  ) 
    values ( stg.terminal_id,stg.terminal_type,stg.terminal_city,stg.terminal_address,to_date('{0}','YYYY.MM.DD HH24-MI-SS'),to_date( '31.12.9999 00-00-00', 'DD.MM.YYYY HH24-MI-SS' ), 'N' )""".format(dt_to_sql))
curs.execute("""
insert into de1m.mkbn_dwh_dim_terminals_hist ( terminal_id,terminal_type,terminal_city,terminal_address,effective_from,effective_to,deleted_flg  ) 
select
    stg.terminal_id,
    stg.terminal_type,
    stg.terminal_city,
    stg.terminal_address,
    to_date('{0}','YYYY.MM.DD HH24-MI-SS'),
    to_date( '31.12.9999 00-00-00', 'DD.MM.YYYY HH24-MI-SS' ), 
    'N'
from de1m.mkbn_curr_time,de1m.mkbn_dwh_dim_terminals_hist tgt
inner join de1m.mkbn_stg_terminals stg
on ( stg.terminal_id = tgt.terminal_id and (tgt.effective_to =to_date('{0}','YYYY.MM.DD HH24-MI-SS')-interval '1' second) and deleted_flg = 'N' )
where 1=0
    or stg.terminal_type <> tgt.terminal_type or ( stg.terminal_type is null and tgt.terminal_type is not null ) or ( stg.terminal_type is not null and tgt.terminal_type is null )
    or stg.terminal_city <> tgt.terminal_city or ( stg.terminal_city is null and tgt.terminal_city is not null ) or ( stg.terminal_city is not null and tgt.terminal_city is null )
    or stg.terminal_address <> tgt.terminal_address or ( stg.terminal_address is null and tgt.terminal_address is not null ) or ( stg.terminal_address is not null and tgt.terminal_address is null )
""".format(dt_to_sql))
curs.execute("""
insert into de1m.mkbn_dwh_dim_terminals_hist ( terminal_id,terminal_type,terminal_city,terminal_address,effective_from,effective_to,deleted_flg  ) 
select
    tgt.terminal_id,
    tgt.terminal_type,
    tgt.terminal_city,
    tgt.terminal_address,
    to_date('{0}','YYYY.MM.DD HH24-MI-SS'),
    to_date( '31.12.9999 00-00-00', 'DD.MM.YYYY HH24-MI-SS' ), 
    'Y'
from de1m.mkbn_dwh_dim_terminals_hist tgt
left join de1m.mkbn_stg_terminals_del stg
on ( stg.terminal_id = tgt.terminal_id and tgt.effective_to = to_date( '31.12.9999 00-00-00', 'DD.MM.YYYY HH24-MI-SS' ) and deleted_flg = 'N' )
where stg.terminal_id is null""".format(dt_to_sql))
curs.execute("""
update de1m.mkbn_dwh_dim_terminals_hist tgt
set effective_to = to_date( '{0}', 'YYYY.MM.DD HH24-MI-SS' ) - interval '1' second
where tgt.terminal_id not in (select terminal_id from de1m.mkbn_stg_terminals_del)
and tgt.effective_to = to_date( '31.12.9999 00-00-00', 'DD.MM.YYYY HH24-MI-SS' )
and tgt.deleted_flg = 'N'""".format(dt_to_sql))
conn.commit()
os.rename(terminals,terminals+".backup")
source_path=terminals+".backup"
if os.path.exists(source_path):
    destination_path=r"/home/de1m/mkbn/archive"
    new_location = shutil.move(source_path, destination_path)
curs.close()
conn.close()
