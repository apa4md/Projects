import pandas
import jaydebeapi
import os
import re
import datetime
import shutil
conn = jaydebeapi.connect( 
'oracle.jdbc.driver.OracleDriver',
'jdbc:oracle:thin:de1m/samwisegamgee@de-oracle.chronosavant.ru:1521/deoracle',
['de1m','samwisegamgee'],
'/home/de1m/ojdbc8.jar'
)
curs = conn.cursor()
conn.jconn.setAutoCommit(False)
for file in os.listdir('/home/de1m/mkbn'):
    if re.search('transactions.',file):
        transactions=os.path.join('/home/de1m/mkbn',file)
df=pandas.read_table(transactions,encoding='cp1251',sep=';',decimal=',')
df=df.reindex(columns=['transaction_id','transaction_date','card_num','oper_type','amount','oper_result','terminal'])
name, ext = os.path.splitext(transactions)
dt=datetime.datetime.strptime(str(name.split('_')[-1]), '%d%m%Y')
dt_to_sql=dt.strftime('%Y-%m-%d %H:%M:%S')
df=df.loc[df['transaction_date'].str[:10]==dt_to_sql[:10]]
df=df.astype(str)
curs.executemany("insert into de1m.mkbn_dwh_fact_transactions(trans_id,trans_date,card_num,oper_type,amt,oper_result,terminal) values(?,to_date(?,'YYYY-MM-DD HH24:MI:SS'),?,?,?,?,?)",df.values.tolist())
conn.commit()
os.rename(transactions,transactions+".backup")
source_path=transactions+".backup"
if os.path.exists(source_path):
    destination_path=r"/home/de1m/mkbn/archive"
    new_location = shutil.move(source_path, destination_path)
curs.close()
conn.close()